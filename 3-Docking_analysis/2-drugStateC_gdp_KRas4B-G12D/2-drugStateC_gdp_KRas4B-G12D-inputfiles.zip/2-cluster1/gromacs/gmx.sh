#!/bin/bash
#############################
#SBATCH -J gdp_C2
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=20
#SBATCH -t 72:00:00
#SBATCH -o be-gromacs-%j.out
#SBATCH -e be-gromacs-%j.err
#SBATCH -D .
#SBATCH --gres=gpu:1
###SBATCH --qos=acc_debug
#SBATCH --qos=acc_resa
#SBATCH --account=upc100

module purge
module load cuda
module load nvidia-hpc-sdk/23.11
module load gromacs/2023.3

export SRUN_CPUS_PER_TASK=${SLURM_CPUS_PER_TASK}
export SLURM_CPU_BIND=none

# minimization
 time mpirun --bind-to none \
 -x OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK gmx_mpi grompp -f step4.0_minimization.mdp -o step4.0_minimization.tpr -c step3_input.gro -r step3_input.gro -p topol.top -n index.ndx
 time mpirun --bind-to none \
 -x OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK gmx_mpi mdrun -deffnm step4.0_minimization

# step4.1
 time mpirun --bind-to none \
 -x OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK gmx_mpi grompp -f step4.1_equilibration.mdp -o step4.1_equilibration.tpr -c step4.0_minimization.gro -r step3_input.gro -p topol.top -n index.ndx
 time mpirun --bind-to none \
 -x OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK gmx_mpi mdrun -deffnm step4.1_equilibration
#unsetenv GMX_MAXCONSTRWARN

# Equilibration
 time mpirun --bind-to none \
 -x OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK gmx_mpi grompp -f step4.2_equilibration.mdp -o step4.2_equilibration.tpr -c step4.1_equilibration.gro -r step3_input.gro -p topol.top -n index.ndx
 time mpirun --bind-to none \
 -x OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK gmx_mpi mdrun -deffnm step4.2_equilibration

# Production
 time mpirun --bind-to none \
 -x OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK gmx_mpi grompp -f step5_production.mdp -o step5_production.tpr -c step4.2_equilibration.gro -p topol.top -n index.ndx
 time mpirun --bind-to none \
 -x OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK gmx_mpi mdrun -deffnm step5_production

mkdir run1
cp step5_production.gro run1/tmp.gro
cp step5_production.cpt run1/tmp.cpt

    export jb=1
    for((i=${jb};i<=10;i++))
    do
    time mpirun --bind-to none \
    -x OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK gmx_mpi grompp -f step6_production.mdp -o run1/step6.${i}_production.tpr -c run1/tmp.gro -t run1/tmp.cpt -p topol.top -n index.ndx
    rm run1/tmp.gro
    rm run1/tmp.cpt
    time mpirun --bind-to none \
    -x OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK gmx_mpi mdrun -v -deffnm run1/step6.${i}_production
    cp run1/step6.${i}_production.gro run1/tmp.gro
    cp run1/step6.${i}_production.cpt run1/tmp.cpt
    done
